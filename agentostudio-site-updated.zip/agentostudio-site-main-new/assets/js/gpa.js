/* Agento Studio — interactive GPA calculators (EN US/UK, DE, ES, PT). No dependencies. */
(function (root) {
  'use strict';

  /* ---------- grading systems ---------- */
  var US_LETTERS = [['A+', 4], ['A', 4], ['A-', 3.7], ['B+', 3.3], ['B', 3], ['B-', 2.7], ['C+', 2.3], ['C', 2], ['C-', 1.7], ['D+', 1.3], ['D', 1], ['D-', 0.7], ['F', 0]];

  function range(a, b, step, dec) {
    var out = [];
    for (var v = a; v <= b + 1e-9; v += step) out.push(+v.toFixed(dec));
    return out;
  }

  var CONFIG = {
    en: {
      locale: 'en-US',
      t: {
        course: 'Course', coursePh: 'Course name (optional)', grade: 'Grade', credits: 'Credits', creditsPh: 'e.g. 3',
        add: 'Add course', calc: 'Calculate', reset: 'Reset', remove: 'Remove course',
        result: 'Your result', credTot: 'Credits counted', points: 'Weighted total',
        none: 'Enter a grade and credits, then press Calculate.',
        bad: '{n} row(s) with an invalid grade or credits are ignored.',
        pick: 'Select'
      },
      modes: [
        {
          id: 'us', tab: 'US 4.0 (letters)', scale: 'US 4.0 scale · A = 4.0, F = 0.0', type: 'select',
          options: US_LETTERS, min: 0, max: 4, dec: 2, maxLabel: '4.0', minLabel: '0.0',
          fail: function (g) { return g < 0.7; },
          unitPoints: 'Quality points', avgLabel: 'GPA',
          meter: function (a) { return a / 4; },
          classify: function (a) {
            if (a >= 3.7) return 'Excellent standing';
            if (a >= 3.3) return 'Very good standing';
            if (a >= 3.0) return 'Good standing';
            if (a >= 2.0) return 'Satisfactory';
            if (a >= 1.0) return 'Passing, but low';
            return 'Below passing';
          },
          failAvg: function (a) { return a < 1.0; },
          note: 'Unweighted 4.0 scale with plus/minus grades. Some schools give A+ a 4.3 or skip plus/minus grades, and repeated courses are handled differently at each school, so check your registrar’s policy.'
        },
        {
          id: 'uk', tab: 'UK degree (%)', scale: 'UK percentage marks · pass mark 40%', type: 'text',
          hint: [], min: 0, max: 100, dec: 1, maxLabel: '100%', minLabel: '0%', unit: '%',
          fail: function (g) { return g < 40; },
          avgLabel: 'Weighted average',
          meter: function (a) { return a / 100; },
          classify: function (a) {
            if (a >= 70) return 'First-class honours (1st)';
            if (a >= 60) return 'Upper second (2:1)';
            if (a >= 50) return 'Lower second (2:2)';
            if (a >= 40) return 'Third-class honours (3rd)';
            return 'Fail';
          },
          failAvg: function (a) { return a < 40; },
          note: 'Weighted average of module percentages using credits. Universities apply their own weighting by year, rounding and borderline rules, so treat the classification as an estimate.'
        }
      ]
    },

    de: {
      locale: 'de-DE',
      t: {
        course: 'Modul', coursePh: 'Modulname (optional)', grade: 'Note', credits: 'LP', creditsPh: 'z. B. 6',
        add: 'Modul hinzufügen', calc: 'Berechnen', reset: 'Zurücksetzen', remove: 'Modul entfernen',
        result: 'Dein Notenschnitt', credTot: 'Berücksichtigte LP', points: 'Σ Note × LP',
        none: 'Trage Note und LP ein und klicke auf „Berechnen“.',
        bad: '{n} Zeile(n) mit ungültiger Note oder ungültigen LP werden ignoriert.',
        pick: 'Wählen'
      },
      modes: [
        {
          id: 'de', tab: '1,0 – 5,0', scale: 'Deutsche Notenskala · 1,0 = sehr gut, 4,0 = bestanden, 5,0 = nicht bestanden', type: 'text',
          hint: [1, 1.3, 1.7, 2, 2.3, 2.7, 3, 3.3, 3.7, 4, 5], min: 1, max: 5, dec: 2, maxLabel: '1,0', minLabel: '5,0',
          fail: function (g) { return g > 4; },
          countFailDefault: false,
          avgLabel: 'Notenschnitt',
          rounding: 'trunc',
          meter: function (a) { return (5 - a) / 4; },
          classify: function (a) {
            if (a <= 1.5) return 'sehr gut';
            if (a <= 2.5) return 'gut';
            if (a <= 3.5) return 'befriedigend';
            if (a <= 4.0) return 'ausreichend';
            return 'nicht ausreichend';
          },
          failAvg: function (a) { return a > 4; },
          note: 'Gewichteter Durchschnitt nach Leistungspunkten (LP/ECTS). Rundung, Gewichtung der Abschlussarbeit und unbenotete Module regelt die Prüfungsordnung deines Studiengangs – prüfe das Ergebnis dort.'
        }
      ]
    },

    es: {
      locale: 'es-ES',
      t: {
        course: 'Asignatura', coursePh: 'Nombre (opcional)', grade: 'Nota', credits: 'Créditos', creditsPh: 'p. ej. 6',
        add: 'Añadir asignatura', calc: 'Calcular', reset: 'Restablecer', remove: 'Quitar asignatura',
        result: 'Tu nota media', credTot: 'Créditos computados', points: 'Σ nota × créditos',
        none: 'Introduce nota y créditos y pulsa «Calcular».',
        bad: '{n} fila(s) con nota o créditos no válidos se ignoran.',
        pick: 'Elegir'
      },
      modes: [
        {
          id: 'es', tab: 'Escala 0 – 10', scale: 'Escala española 0–10 · aprobado desde 5,0', type: 'text',
          hint: range(5, 10, 0.5, 1), min: 0, max: 10, dec: 2, maxLabel: '10', minLabel: '0',
          fail: function (g) { return g < 5; },
          countFailDefault: true,
          avgLabel: 'Nota media',
          meter: function (a) { return a / 10; },
          classify: function (a) {
            if (a >= 9) return 'Sobresaliente';
            if (a >= 7) return 'Notable';
            if (a >= 5) return 'Aprobado';
            return 'Suspenso';
          },
          failAvg: function (a) { return a < 5; },
          note: 'Media ponderada por créditos ECTS. Las Matrículas de Honor suelen computar como 9,0–10 según tu universidad, y el tratamiento de convocatorias, adaptadas y reconocidas depende de su normativa: consulta la secretaría de tu facultad.'
        }
      ]
    },

    pt: {
      locale: 'pt-PT',
      t: {
        course: 'Unidade curricular', coursePh: 'Nome da UC (opcional)', grade: 'Nota', credits: 'ECTS', creditsPh: 'ex. 6',
        add: 'Adicionar UC', calc: 'Calcular', reset: 'Repor', remove: 'Remover UC',
        result: 'A sua média', credTot: 'ECTS considerados', points: 'Σ nota × ECTS',
        none: 'Introduza nota e ECTS e clique em «Calcular».',
        bad: '{n} linha(s) com nota ou ECTS inválidos são ignoradas.',
        pick: 'Escolher'
      },
      modes: [
        {
          id: 'pt', tab: 'Escala 0 – 20', scale: 'Escala portuguesa 0–20 · aprovação a partir de 10 valores', type: 'text',
          hint: range(10, 20, 1, 0), min: 0, max: 20, dec: 2, maxLabel: '20', minLabel: '0',
          fail: function (g) { return g < 10; },
          countFailDefault: false,
          avgLabel: 'Média',
          meter: function (a) { return a / 20; },
          classify: function (a) {
            var r = Math.round(a);
            if (a < 9.5) return 'Insuficiente';
            if (r >= 18) return 'Excelente';
            if (r >= 16) return 'Muito bom';
            if (r >= 14) return 'Bom';
            return 'Suficiente';
          },
          failAvg: function (a) { return a < 9.5; },
          note: 'Média ponderada pelos créditos ECTS. A média final é arredondada às unidades e classificada segundo o regulamento da sua instituição (Suficiente 10–13, Bom 14–15, Muito bom 16–17, Excelente 18–20); confirme nos serviços académicos.'
        }
      ]
    }
  };

  /* ---------- pure logic (exported for tests) ---------- */
  function parse(s) {
    if (s === null || s === undefined) return NaN;
    s = String(s).trim().replace(',', '.');
    if (s === '') return NaN;
    return Number(s);
  }

  function isBlank(s) { return s === null || s === undefined || String(s).trim() === ''; }

  function round(v, d) { var f = Math.pow(10, d); return Math.round((v + 1e-12) * f) / f; }

  function compute(mode, rows, o) {
    o = o || {};
    var sumW = 0, sumQ = 0, used = 0, bad = 0, states = [], i;
    for (i = 0; i < rows.length; i++) {
      var r = rows[i], g = parse(r.g), c = parse(r.c);
      var gBlank = isBlank(r.g), cBlank = isBlank(r.c);
      if (gBlank && cBlank) { states.push('empty'); continue; }
      var gOk = !isNaN(g) && g >= mode.min && g <= mode.max;
      var cOk = !isNaN(c) && c > 0 && c <= 1000;
      if (!gOk || !cOk) { states.push('bad'); bad++; continue; }
      var failed = mode.fail(g);
      states.push(failed ? 'fail' : 'ok');
      if (failed && !o.countFailed) continue;
      sumW += c; sumQ += g * c; used++;
    }

    var res = { states: states, bad: bad, credits: sumW, points: sumQ, used: used, avg: null, shown: null, label: '' };
    if (sumW > 0) {
      var avg = sumQ / sumW, v;
      if (o.rounding === 'trunc') v = Math.floor(avg * 10 + 1e-9) / 10;
      else v = round(avg, mode.dec);
      res.avg = avg; res.value = v;
      res.decimals = o.rounding === 'trunc' ? 1 : mode.dec;
      res.label = mode.classify(v);
      res.failAvg = mode.failAvg(v);
    }
    return res;
  }

  /* ---------- UI ---------- */
  function fmt(n, d, locale) {
    return n.toLocaleString(locale, { minimumFractionDigits: d, maximumFractionDigits: d });
  }
  function fmtCredits(n, locale) {
    return n.toLocaleString(locale, { maximumFractionDigits: 1 });
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function hintText(v, locale) { return fmt(v, v % 1 === 0 ? (v >= 10 || locale === 'x' ? 0 : 1) : 1, locale); }

  function mount(el) {
    var lang = el.getAttribute('data-gpa');
    var cfg = CONFIG[lang];
    if (!cfg) return;
    var T = cfg.t, modes = cfg.modes, uid = 'gc' + Math.random().toString(36).slice(2, 7);
    var KEY = 'agento-gpa-' + lang;
    var state = { mode: modes[0].id, data: {} };
    var calculated = false;

    function blankRows(n) { var a = []; for (var i = 0; i < n; i++) a.push({ n: '', g: '', c: '' }); return a; }
    function ensure(m) {
      if (!state.data[m.id] || !state.data[m.id].rows) state.data[m.id] = { rows: blankRows(4) };
      state.data[m.id].opts = { countFailed: m.countFailDefault !== false, rounding: m.rounding || '' };
      return state.data[m.id];
    }
    function curMode() { for (var i = 0; i < modes.length; i++) if (modes[i].id === state.mode) return modes[i]; return modes[0]; }

    try {
      var saved = JSON.parse(localStorage.getItem(KEY) || 'null');
      if (saved && saved.data) { state = saved; if (!modes.some(function (m) { return m.id === state.mode; })) state.mode = modes[0].id; }
    } catch (e) {}
    modes.forEach(ensure);

    function save() {
      try {
        var out = { mode: state.mode, data: {} };
        for (var k in state.data) out.data[k] = { rows: state.data[k].rows };
        localStorage.setItem(KEY, JSON.stringify(out));
      } catch (e) {}
    }

    function gradeControl(m, row, idx) {
      var attrs = 'data-f="g" data-i="' + idx + '" aria-label="' + esc(T.grade) + ' ' + (idx + 1) + '"';
      if (m.type === 'select') {
        var h = '<select ' + attrs + '><option value="">' + esc(T.pick) + '</option>';
        m.options.forEach(function (o) {
          h += '<option value="' + o[1] + '"' + (String(row.g) === String(o[1]) && row.g !== '' && state._last === o[0] + idx ? ' selected' : '') + ' data-l="' + o[0] + '">' + o[0] + ' · ' + fmt(o[1], 1, cfg.locale) + '</option>';
        });
        return h + '</select>';
      }
      return '<input type="text" inputmode="decimal" autocomplete="off" ' + attrs + ' list="' + uid + '-dl" value="' + esc(row.g) + '" placeholder="' + esc(m.min + '–' + m.max).replace(/\./g, cfg.locale.indexOf('en') === 0 ? '.' : ',') + (m.unit || '') + '">';
    }

    function rowHtml(m, row, idx) {
      return '<div class="gc-row" data-row="' + idx + '">' +
        '<input type="text" data-f="n" data-i="' + idx + '" maxlength="60" autocomplete="off" aria-label="' + esc(T.course) + ' ' + (idx + 1) + '" placeholder="' + esc(T.coursePh) + '" value="' + esc(row.n) + '">' +
        gradeControl(m, row, idx) +
        '<input type="text" inputmode="decimal" autocomplete="off" data-f="c" data-i="' + idx + '" aria-label="' + esc(T.credits) + ' ' + (idx + 1) + '" placeholder="' + esc(T.creditsPh) + '" value="' + esc(row.c) + '">' +
        '<button type="button" class="gc-del" data-del="' + idx + '" aria-label="' + esc(T.remove) + ' ' + (idx + 1) + '" title="' + esc(T.remove) + '">×</button></div>';
    }

    function build() {
      var m = curMode(), d = ensure(m), h = '';
      h += '<div class="gc-head">';
      if (modes.length > 1) {
        h += '<div class="gc-tabs" role="tablist">';
        modes.forEach(function (x) { h += '<button type="button" role="tab" class="gc-tab" data-mode="' + x.id + '" aria-selected="' + (x.id === m.id) + '">' + esc(x.tab) + '</button>'; });
        h += '</div>';
      } else h += '<div class="gc-tabs"><span class="gc-tab" aria-selected="true">' + esc(m.tab) + '</span></div>';
      h += '<div class="gc-scale">' + esc(m.scale) + '</div></div>';

      h += '<div class="gc-body"><div class="gc-form">';
      h += '<div class="gc-cols" aria-hidden="true"><span>' + esc(T.course) + '</span><span>' + esc(T.grade) + '</span><span>' + esc(T.credits) + '</span><span></span></div>';
      h += '<div class="gc-rows" id="' + uid + '-rows">';
      d.rows.forEach(function (r, i) { h += rowHtml(m, r, i); });
      h += '</div>';
      if (m.type === 'text' && m.hint && m.hint.length) {
        h += '<datalist id="' + uid + '-dl">' + m.hint.map(function (v) { return '<option value="' + fmt(v, v % 1 === 0 && v >= 10 ? 0 : 1, cfg.locale) + '">'; }).join('') + '</datalist>';
      }
      h += '<div class="gc-actions"><button type="button" class="btn btn-p gc-calc" data-act="calc">' + esc(T.calc) + '</button><button type="button" class="btn btn-s gc-add" data-act="add">' + esc(T.add) + '</button><button type="button" class="btn btn-s" data-act="reset">' + esc(T.reset) + '</button></div>';

      h += '</div>';

      h += '<div class="gc-out" aria-live="polite"><div class="gc-label">' + esc(T.result) + '</div>' +
        '<div class="gc-big is-empty" data-out="big">–</div><span class="gc-class" data-out="class"></span>' +
        '<div><div class="gc-meter" role="presentation"><i data-out="bar"></i></div><div class="gc-meter-ends"><span>' + esc(m.minLabel) + '</span><span>' + esc(m.maxLabel) + '</span></div></div>' +
        '<div class="gc-stats"><div><b data-out="cred">–</b><span>' + esc(T.credTot) + '</span></div><div><b data-out="pts">–</b><span>' + esc(m.unitPoints || T.points) + '</span></div></div>' +
        '<p class="gc-msg" data-out="msg"></p></div></div>';
      h += '<p class="gc-note">' + esc(m.note) + '</p>';
      el.innerHTML = h;
      update();
    }

    function q(sel) { return el.querySelector(sel); }

    function update() {
      var m = curMode(), d = ensure(m), loc = cfg.locale;
      var res = calculated ? compute(m, d.rows, d.opts) : { states: [], bad: 0, avg: null };
      var big = q('[data-out=big]'), cls = q('[data-out=class]'), bar = q('[data-out=bar]');
      var rowsEls = el.querySelectorAll('.gc-row');
      for (var i = 0; i < rowsEls.length; i++) {
        rowsEls[i].classList.toggle('is-bad', res.states[i] === 'bad' || res.states[i] === 'fail');
      }
      if (res.avg === null) {
        big.textContent = '–'; big.classList.add('is-empty'); cls.textContent = ''; bar.style.width = '0';
        q('[data-out=cred]').textContent = '–'; q('[data-out=pts]').textContent = '–';
      } else {
        big.classList.remove('is-empty');
        big.textContent = fmt(res.value, res.decimals, loc) + (m.unit || '');
        cls.textContent = res.label; cls.classList.toggle('is-fail', !!res.failAvg);
        var p = Math.max(0, Math.min(1, m.meter(res.value)));
        bar.style.width = (p * 100).toFixed(1) + '%';
        q('[data-out=cred]').textContent = fmtCredits(res.credits, loc);
        q('[data-out=pts]').textContent = fmt(res.points, 1, loc);
      }
      var msg = '';
      if (!calculated) msg = '';
      else if (res.bad) msg = T.bad.replace('{n}', res.bad);
      else if (res.avg === null) msg = T.none;
      q('[data-out=msg]').textContent = msg;
      save();
    }

    el.addEventListener('input', function (e) {
      var t = e.target, m = curMode(), d = ensure(m);
      if (t.hasAttribute('data-f')) {
        var i = +t.getAttribute('data-i'), f = t.getAttribute('data-f');
        if (d.rows[i]) d.rows[i][f] = t.value;
        calculated = false; update();
      }
    });
    el.addEventListener('change', function (e) {
      var t = e.target, m = curMode(), d = ensure(m);
      if (t.tagName === 'SELECT' && t.hasAttribute('data-f')) {
        var i = +t.getAttribute('data-i'); d.rows[i].g = t.value; calculated = false; update();
      }
    });
    el.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && e.target.tagName === 'INPUT') { e.preventDefault(); calculated = true; update(); }
    });
    el.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      var m = curMode(), d = ensure(m);
      if (b.hasAttribute('data-mode')) { state.mode = b.getAttribute('data-mode'); calculated = false; build(); return; }
      if (b.hasAttribute('data-del')) {
        var i = +b.getAttribute('data-del');
        if (d.rows.length > 1) d.rows.splice(i, 1); else d.rows[0] = { n: '', g: '', c: '' };
        calculated = false; build(); return;
      }
      var act = b.getAttribute('data-act');
      if (act === 'calc') {
        calculated = true; update();
      } else if (act === 'add') {
        if (d.rows.length >= 40) return;
        d.rows.push({ n: '', g: '', c: '' }); build();
        var inputs = el.querySelectorAll('.gc-row:last-child input'); if (inputs[0]) inputs[0].focus();
      } else if (act === 'reset') {
        delete state.data[m.id]; ensure(m); calculated = false; build();
      }
    });

    build();
  }

  function init() {
    var els = document.querySelectorAll('[data-gpa]');
    for (var i = 0; i < els.length; i++) mount(els[i]);
  }

  var api = { CONFIG: CONFIG, compute: compute, parse: parse };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof document !== 'undefined') {
    root.AgentoGPA = api;
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  }
})(typeof window !== 'undefined' ? window : this);
