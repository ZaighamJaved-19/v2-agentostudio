/* Agento Studio — document converter settings.
 *
 * Conversions run on the Python backend (agentostudio-backend/), which holds the Adobe and
 * CloudConvert keys privately. NO secret keys belong in this file — it is public.
 *
 * After deploying the backend, put its public URL in `apiBase`, e.g.
 *   apiBase: "https://converter.agentostudio.tech"
 * On localhost the site automatically uses http://localhost:8000.
 */
window.AGENTO_CONVERTER = {
  apiBase: (location.hostname === "localhost" || location.hostname === "127.0.0.1") ? "http://localhost:8000" : "",

  // Largest file accepted in the browser (the backend enforces its own limit too).
  maxFileBytes: 50 * 1024 * 1024
};
