(function(){var b=document.getElementById('menuToggle'),n=document.getElementById('navLinks');if(!b||!n)return;
function s(o){n.classList.toggle('open',o);b.setAttribute('aria-expanded',o?'true':'false');b.textContent=o?'✕':'☰';}
b.addEventListener('click',function(){s(!n.classList.contains('open'));});
n.addEventListener('click',function(e){if(e.target.closest('a'))s(false);});
document.addEventListener('keydown',function(e){if(e.key==='Escape')s(false);});
window.addEventListener('resize',function(){if(window.innerWidth>1000)s(false);});})();
