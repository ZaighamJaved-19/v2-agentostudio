/* Agento Studio — web document converter.
 * Port of doc_converter_feature.dart: Adobe PDF Services (primary) -> CloudConvert (automatic backup).
 * Four conversions: PDF->Word, Word->PDF, PPT->PDF, PDF->PPT.
 */
(function (root) {
  'use strict';

  var CFG = (root && root.AGENTO_CONVERTER) || {};

  /* ---------- model ---------- */
  var MIME = {
    pdf: 'application/pdf',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    doc: 'application/msword',
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    ppt: 'application/vnd.ms-powerpoint'
  };

  var KINDS = [
    { id: 'pdfToWord', from: 'PDF', to: 'DOCX', inputs: ['pdf'], out: 'docx', isExport: true },
    { id: 'wordToPdf', from: 'DOCX', to: 'PDF', inputs: ['docx', 'doc'], out: 'pdf', isExport: false },
    { id: 'pptToPdf', from: 'PPTX', to: 'PDF', inputs: ['pptx', 'ppt'], out: 'pdf', isExport: false },
    { id: 'pdfToPpt', from: 'PDF', to: 'PPTX', inputs: ['pdf'], out: 'pptx', isExport: true }
  ];

  function ConversionError(message) { this.name = 'ConversionError'; this.message = message; }
  ConversionError.prototype = Object.create(Error.prototype);
  function Cancelled() { this.name = 'Cancelled'; this.message = 'cancelled'; }
  Cancelled.prototype = Object.create(Error.prototype);

  function makeCancel() {
    var ac = new AbortController();
    return {
      signal: ac.signal,
      cancel: function () { ac.abort(); },
      check: function () { if (ac.signal.aborted) throw new Cancelled(); }
    };
  }

  function adobeReady() { return !!(CFG.adobeClientId && CFG.adobeClientSecret); }
  function cloudReady() { return !!CFG.cloudConvertApiKey; }
  function anyProvider() { return adobeReady() || cloudReady(); }

  function errorText(body) {
    try {
      var j = JSON.parse(body);
      if (j && typeof j === 'object') {
        var e = j.error;
        if (e && typeof e === 'object' && e.message != null) return String(e.message);
        if (typeof e === 'string') return e;
        if (j.message != null) return String(j.message);
        if (j.error_description != null) return String(j.error_description);
      }
    } catch (x) {}
    body = String(body || '');
    return body.length > 200 ? body.slice(0, 200) + '…' : body;
  }

  function sleep(ms, ctl) {
    return new Promise(function (res, rej) {
      var t = setTimeout(function () { ctl.signal.removeEventListener('abort', onAbort); res(); }, ms);
      function onAbort() { clearTimeout(t); rej(new Cancelled()); }
      ctl.signal.addEventListener('abort', onAbort, { once: true });
    });
  }

  /* fetch with timeout + cancel; network problems become friendly ConversionErrors */
  function request(url, opts, ms, ctl, T) {
    var ac = new AbortController(), timedOut = false;
    var timer = setTimeout(function () { timedOut = true; ac.abort(); }, ms);
    var onAbort = function () { ac.abort(); };
    ctl.signal.addEventListener('abort', onAbort);
    var o = {};
    for (var k in opts) o[k] = opts[k];
    o.signal = ac.signal;
    return fetch(url, o).then(function (r) {
      clearTimeout(timer); ctl.signal.removeEventListener('abort', onAbort);
      return r;
    }, function () {
      clearTimeout(timer); ctl.signal.removeEventListener('abort', onAbort);
      if (ctl.signal.aborted) throw new Cancelled();
      if (timedOut) throw new ConversionError(T.timeout);
      throw new ConversionError(T.network);
    });
  }

  var SEC = 1000, MIN = 60000;

  /* ---------- Adobe PDF Services (primary) ---------- */
  var ADOBE = 'https://pdf-services.adobe.io';
  var adobeTok = { token: null, expiry: 0 };

  function adobeAuth(token, json) {
    var h = { 'Authorization': 'Bearer ' + token, 'x-api-key': CFG.adobeClientId };
    if (json) h['Content-Type'] = 'application/json';
    return h;
  }

  async function adobeToken(ctl, T) {
    if (adobeTok.token && Date.now() < adobeTok.expiry) return adobeTok.token;
    var r = await request(ADOBE + '/token', {
      method: 'POST',
      body: new URLSearchParams({ client_id: CFG.adobeClientId, client_secret: CFG.adobeClientSecret })
    }, 30 * SEC, ctl, T);
    var body = await r.text();
    if (r.status !== 200) throw new ConversionError('Adobe sign-in failed (' + r.status + '): ' + errorText(body));
    var j = JSON.parse(body);
    adobeTok.token = j.access_token;
    var secs = Number(j.expires_in) || 3600;
    var life = secs > 100000 ? Math.floor(secs / 1000) : secs; // seconds or milliseconds
    adobeTok.expiry = Date.now() + (life - 60) * 1000;
    return adobeTok.token;
  }

  async function adobeConvert(kind, file, ext, ctl, onStatus, T) {
    var mime = MIME[ext];
    onStatus('adobeSign');
    var token = await adobeToken(ctl, T);
    ctl.check();

    // 1) upload slot
    onStatus('adobeUpload');
    var slot = await request(ADOBE + '/assets', { method: 'POST', headers: adobeAuth(token, true), body: JSON.stringify({ mediaType: mime }) }, 30 * SEC, ctl, T);
    var slotBody = await slot.text();
    if (slot.status !== 200 && slot.status !== 202) throw new ConversionError('Adobe upload slot failed (' + slot.status + '): ' + errorText(slotBody));
    var slotJson = JSON.parse(slotBody);
    var assetId = slotJson.assetID, uploadUri = slotJson.uploadUri;

    // 2) PUT the bytes to the pre-signed URL
    var up = await request(uploadUri, { method: 'PUT', headers: { 'Content-Type': mime }, body: file }, 5 * MIN, ctl, T);
    if (up.status !== 200 && up.status !== 201) throw new ConversionError('Adobe upload failed (' + up.status + ').');
    ctl.check();

    // 3) submit the job
    onStatus('adobeConvert');
    var op = kind.isExport ? 'exportpdf' : 'createpdf';
    var payload = { assetID: assetId };
    if (kind.isExport) payload.targetFormat = kind.out;
    var submit = await request(ADOBE + '/operation/' + op, { method: 'POST', headers: adobeAuth(token, true), body: JSON.stringify(payload) }, 30 * SEC, ctl, T);
    var submitBody = await submit.text();
    if (submit.status !== 201) throw new ConversionError('Adobe rejected the job (' + submit.status + '): ' + errorText(submitBody));
    var location = submit.headers.get('location');
    if (!location) throw new ConversionError('Adobe did not return a job location.');

    // 4) poll until done
    var deadline = Date.now() + 6 * MIN, downloadUri = null;
    for (;;) {
      ctl.check();
      if (Date.now() > deadline) throw new ConversionError('Adobe took too long to finish.');
      var p = await request(location, { method: 'GET', headers: adobeAuth(token) }, 30 * SEC, ctl, T);
      var pBody = await p.text();
      if (p.status !== 200 && p.status !== 202) throw new ConversionError('Adobe status check failed (' + p.status + '): ' + errorText(pBody));
      var j = JSON.parse(pBody);
      var status = String(j.status || '').toLowerCase();
      if (status === 'done') { downloadUri = j.asset && j.asset.downloadUri; break; }
      if (status === 'failed') throw new ConversionError('Adobe could not convert this file: ' + errorText(pBody));
      var retry = parseInt(p.headers.get('retry-after'), 10);
      if (isNaN(retry)) retry = 2;
      await sleep(Math.min(5, Math.max(1, retry)) * SEC, ctl);
    }
    if (!downloadUri) throw new ConversionError('Adobe finished but returned no file.');

    // 5) download (pre-signed URL: no auth headers)
    onStatus('adobeDownload');
    var dl = await request(downloadUri, { method: 'GET' }, 5 * MIN, ctl, T);
    if (dl.status !== 200) throw new ConversionError('Adobe download failed (' + dl.status + ').');
    return { blob: await dl.blob() };
  }

  /* ---------- CloudConvert (backup) ---------- */
  function ccBase() {
    return CFG.cloudConvertSandbox ? 'https://api.sandbox.cloudconvert.com/v2' : 'https://api.cloudconvert.com/v2';
  }
  function ccHeaders() {
    return { 'Authorization': 'Bearer ' + CFG.cloudConvertApiKey, 'Content-Type': 'application/json' };
  }

  async function cloudConvert(kind, file, fileName, ctl, onStatus, T) {
    var base = ccBase();
    onStatus('ccJob');
    var create = await request(base + '/jobs', {
      method: 'POST', headers: ccHeaders(),
      body: JSON.stringify({
        tasks: {
          'import-file': { operation: 'import/upload' },
          'convert-file': { operation: 'convert', input: 'import-file', output_format: kind.out },
          'export-file': { operation: 'export/url', input: 'convert-file' }
        }
      })
    }, 30 * SEC, ctl, T);
    var createBody = await create.text();
    if (create.status !== 201) throw new ConversionError('CloudConvert rejected the job (' + create.status + '): ' + errorText(createBody));
    var data = JSON.parse(createBody).data;
    var jobId = data.id;
    var importTask = data.tasks.filter(function (t) { return t.name === 'import-file'; })[0];
    var form = importTask.result.form;
    ctl.check();

    // upload: every form parameter first, the file LAST (field name "file")
    onStatus('ccUpload');
    var fd = new FormData();
    Object.keys(form.parameters).forEach(function (k) { fd.append(k, String(form.parameters[k])); });
    fd.append('file', file, fileName);
    var up = await request(form.url, { method: 'POST', body: fd }, 5 * MIN, ctl, T);
    if (up.status >= 400) throw new ConversionError('CloudConvert upload failed (' + up.status + ').');
    ctl.check();

    // poll
    onStatus('ccConvert');
    var deadline = Date.now() + 6 * MIN, url = null;
    for (;;) {
      ctl.check();
      if (Date.now() > deadline) throw new ConversionError('CloudConvert took too long to finish.');
      await sleep(2 * SEC, ctl);
      var r = await request(base + '/jobs/' + jobId, { method: 'GET', headers: ccHeaders() }, 30 * SEC, ctl, T);
      var rBody = await r.text();
      if (r.status !== 200) throw new ConversionError('CloudConvert status check failed (' + r.status + '): ' + errorText(rBody));
      var job = JSON.parse(rBody).data, tasks = job.tasks || [];
      if (job.status === 'error') {
        var bad = tasks.filter(function (t) { return t.status === 'error'; });
        var msg = bad.length ? (bad[0].message || bad[0].code || 'unknown error') : 'unknown error';
        throw new ConversionError('CloudConvert could not convert this file: ' + msg);
      }
      if (job.status === 'finished') {
        var exp = tasks.filter(function (t) { return t.name === 'export-file'; })[0];
        var files = exp && exp.result && exp.result.files;
        if (!files || !files.length) throw new ConversionError('CloudConvert returned no file.');
        url = files[0].url;
        break;
      }
    }

    onStatus('ccDownload');
    try {
      var dl = await request(url, { method: 'GET' }, 5 * MIN, ctl, T);
      if (dl.status !== 200) throw new ConversionError('CloudConvert download failed (' + dl.status + ').');
      return { blob: await dl.blob() };
    } catch (e) {
      // If the browser blocks reading the result (CORS), hand the user the direct link instead.
      if (e instanceof Cancelled) throw e;
      return { url: url };
    }
  }

  /* ---------- backend mode: the Python API does Adobe -> CloudConvert server-side ---------- */
  function apiDetail(body, T) {
    try { var j = JSON.parse(body); if (typeof j.detail === 'string') return j.detail; } catch (x) {}
    return T.failed;
  }

  async function backendConvert(kind, file, ctl, onStatus, T) {
    var base = String(CFG.apiBase).replace(/\/+$/, '');
    var fd = new FormData();
    fd.append('kind', kind.id);
    fd.append('file', file, file.name);
    onStatus('upload');
    var r = await request(base + '/api/convert', { method: 'POST', body: fd }, 5 * MIN, ctl, T);
    var body = await r.text();
    if (r.status !== 202) throw new ConversionError(apiDetail(body, T));
    var id = JSON.parse(body).jobId;
    var jobUrl = base + '/api/jobs/' + encodeURIComponent(id);
    function cleanup() { try { fetch(jobUrl, { method: 'DELETE', keepalive: true }).catch(function () {}); } catch (x) {} }

    try {
      var deadline = Date.now() + 8 * MIN;
      for (;;) {
        ctl.check();
        if (Date.now() > deadline) throw new ConversionError(T.timeout);
        await sleep(1200, ctl);
        var p = await request(jobUrl, { method: 'GET' }, 30 * SEC, ctl, T);
        var pb = await p.text();
        if (p.status !== 200) throw new ConversionError(apiDetail(pb, T));
        var j = JSON.parse(pb);
        if (j.stage && T.s[j.stage]) onStatus(j.stage);
        if (j.status === 'error') throw new ConversionError(j.error || T.failed);
        if (j.status === 'cancelled') throw new Cancelled();
        if (j.status === 'done') {
          var f = await request(jobUrl + '/file', { method: 'GET' }, 5 * MIN, ctl, T);
          if (f.status !== 200) throw new ConversionError(apiDetail(await f.text(), T));
          var blob = await f.blob();
          cleanup(); // free the server copy right away
          return { blob: blob, provider: j.provider, usedBackup: !!j.usedBackup };
        }
      }
    } catch (e) {
      cleanup();
      throw e;
    }
  }

  /* ---------- service: Adobe first, CloudConvert automatic backup ---------- */
  async function convertFile(opts) {
    var kind = opts.kind, file = opts.file, ctl = opts.cancel, onStatus = opts.onStatus, T = opts.T;
    if (!CFG.apiBase && !anyProvider()) throw new ConversionError(T.noKeys);
    var name = file.name, dot = name.lastIndexOf('.');
    var ext = dot >= 0 ? name.slice(dot + 1).toLowerCase() : '';
    if (kind.inputs.indexOf(ext) < 0) throw new ConversionError(T.wrongExt.replace('{x}', '.' + kind.inputs.join(' / .')).replace('{k}', kind.from + ' → ' + kind.to));
    if (CFG.apiBase) return backendConvert(kind, file, ctl, onStatus, T);

    var adobeError = null, cloudError = null, out;
    if (adobeReady()) {
      try {
        out = await adobeConvert(kind, file, ext, ctl, onStatus, T);
        out.provider = 'Adobe PDF Services'; out.usedBackup = false;
        return out;
      } catch (e) {
        if (e instanceof Cancelled) throw e;
        adobeError = e && e.message ? e.message : String(e);
        if (root.console) console.warn('Adobe conversion failed:', adobeError);
        if (cloudReady()) onStatus('plain');
      }
    }
    ctl.check();
    if (cloudReady()) {
      try {
        out = await cloudConvert(kind, file, name, ctl, onStatus, T);
        out.provider = 'CloudConvert'; out.usedBackup = adobeReady();
        return out;
      } catch (e) {
        if (e instanceof Cancelled) throw e;
        cloudError = e && e.message ? e.message : String(e);
      }
    }
    throw new ConversionError(cloudError || adobeError || T.failed);
  }

  /* ---------- UI strings ---------- */
  var TEXT = {
    en: {
      choose: 'Choose conversion', kinds: ['Editable .docx', '.docx / .doc to PDF', '.pptx / .ppt to PDF', 'Editable .pptx'],
      drop: 'Drag & drop your file here', dropActive: 'Drop your file here', or: 'or', pickBtn: 'Choose File', change: 'tap to change',
      supports: 'Supports {x} (Max {n} MB)', convert: 'Convert', cancel: 'Cancel', cancelled: 'Conversion cancelled.', large: 'Large files can take a minute.',
      done: 'Converted', via: 'via', backup: 'backup', download: 'Download', downloaded: 'Download started', openLink: 'Open converted file',
      another: 'Convert another file', privacy: 'Your file is sent to Adobe PDF Services (or CloudConvert if Adobe fails) only to be converted. Only convert documents you are allowed to share.',
      noKeys: 'No converter is set up yet.', wrongExt: 'Please choose a {x} file for {k}.', tooBig: 'This file is larger than {n} MB.',
      timeout: 'The request timed out.', network: 'No internet connection, or the service could not be reached.', failed: 'Conversion failed.', wrong: 'Something went wrong: ',
      s: { upload: 'Uploading…', queued: 'Waiting in line…', read: 'Reading file…', plain: 'Converting…', adobeSign: 'Adobe: signing in…', adobeUpload: 'Adobe: uploading…', adobeConvert: 'Adobe: converting…', adobeDownload: 'Adobe: downloading result…', ccJob: 'CloudConvert: creating job…', ccUpload: 'CloudConvert: uploading…', ccConvert: 'CloudConvert: converting…', ccDownload: 'CloudConvert: downloading result…' }
    },
    de: {
      choose: 'Umwandlung wählen', kinds: ['Bearbeitbare .docx', '.docx / .doc zu PDF', '.pptx / .ppt zu PDF', 'Bearbeitbare .pptx'],
      drop: 'Datei hierher ziehen', dropActive: 'Datei hier ablegen', or: 'oder', pickBtn: 'Datei wählen', change: 'zum Ändern tippen',
      supports: 'Unterstützt {x} (max. {n} MB)', convert: 'Umwandeln', cancel: 'Abbrechen', cancelled: 'Umwandlung abgebrochen.', large: 'Große Dateien können eine Minute dauern.',
      done: 'Umgewandelt', via: 'über', backup: 'Ersatzdienst', download: 'Herunterladen', downloaded: 'Download gestartet', openLink: 'Umgewandelte Datei öffnen',
      another: 'Weitere Datei umwandeln', privacy: 'Deine Datei wird nur zur Umwandlung an Adobe PDF Services (bei Fehlern an CloudConvert) gesendet. Wandle nur Dokumente um, die du weitergeben darfst.',
      noKeys: 'Der Konverter ist noch nicht eingerichtet.', wrongExt: 'Bitte wähle eine {x}-Datei für {k}.', tooBig: 'Diese Datei ist größer als {n} MB.',
      timeout: 'Die Anfrage hat zu lange gedauert.', network: 'Keine Internetverbindung oder der Dienst ist nicht erreichbar.', failed: 'Umwandlung fehlgeschlagen.', wrong: 'Etwas ist schiefgelaufen: ',
      s: { upload: 'Wird hochgeladen…', queued: 'In der Warteschlange…', read: 'Datei wird gelesen…', plain: 'Wird umgewandelt…', adobeSign: 'Adobe: Anmeldung…', adobeUpload: 'Adobe: Hochladen…', adobeConvert: 'Adobe: Umwandeln…', adobeDownload: 'Adobe: Ergebnis wird geladen…', ccJob: 'CloudConvert: Auftrag wird erstellt…', ccUpload: 'CloudConvert: Hochladen…', ccConvert: 'CloudConvert: Umwandeln…', ccDownload: 'CloudConvert: Ergebnis wird geladen…' }
    },
    es: {
      choose: 'Elige la conversión', kinds: ['.docx editable', '.docx / .doc a PDF', '.pptx / .ppt a PDF', '.pptx editable'],
      drop: 'Arrastra tu archivo aquí', dropActive: 'Suelta el archivo aquí', or: 'o', pickBtn: 'Elegir archivo', change: 'toca para cambiar',
      supports: 'Admite {x} (máx. {n} MB)', convert: 'Convertir', cancel: 'Cancelar', cancelled: 'Conversión cancelada.', large: 'Los archivos grandes pueden tardar un minuto.',
      done: 'Convertido', via: 'con', backup: 'respaldo', download: 'Descargar', downloaded: 'Descarga iniciada', openLink: 'Abrir archivo convertido',
      another: 'Convertir otro archivo', privacy: 'Tu archivo se envía a Adobe PDF Services (o a CloudConvert si Adobe falla) solo para convertirlo. Convierte únicamente documentos que puedas compartir.',
      noKeys: 'El conversor aún no está configurado.', wrongExt: 'Elige un archivo {x} para {k}.', tooBig: 'Este archivo supera los {n} MB.',
      timeout: 'La solicitud ha tardado demasiado.', network: 'Sin conexión a internet o servicio no disponible.', failed: 'La conversión ha fallado.', wrong: 'Algo ha ido mal: ',
      s: { upload: 'Subiendo…', queued: 'En cola…', read: 'Leyendo archivo…', plain: 'Convirtiendo…', adobeSign: 'Adobe: iniciando sesión…', adobeUpload: 'Adobe: subiendo…', adobeConvert: 'Adobe: convirtiendo…', adobeDownload: 'Adobe: descargando resultado…', ccJob: 'CloudConvert: creando tarea…', ccUpload: 'CloudConvert: subiendo…', ccConvert: 'CloudConvert: convirtiendo…', ccDownload: 'CloudConvert: descargando resultado…' }
    },
    pt: {
      choose: 'Escolha a conversão', kinds: ['.docx editável', '.docx / .doc para PDF', '.pptx / .ppt para PDF', '.pptx editável'],
      drop: 'Arraste o ficheiro para aqui', dropActive: 'Largue o ficheiro aqui', or: 'ou', pickBtn: 'Escolher ficheiro', change: 'toque para alterar',
      supports: 'Suporta {x} (máx. {n} MB)', convert: 'Converter', cancel: 'Cancelar', cancelled: 'Conversão cancelada.', large: 'Ficheiros grandes podem demorar um minuto.',
      done: 'Convertido', via: 'via', backup: 'alternativa', download: 'Transferir', downloaded: 'Transferência iniciada', openLink: 'Abrir ficheiro convertido',
      another: 'Converter outro ficheiro', privacy: 'O seu ficheiro é enviado para o Adobe PDF Services (ou para o CloudConvert se a Adobe falhar) apenas para ser convertido. Converta só documentos que possa partilhar.',
      noKeys: 'O conversor ainda não está configurado.', wrongExt: 'Escolha um ficheiro {x} para {k}.', tooBig: 'Este ficheiro é maior do que {n} MB.',
      timeout: 'O pedido demorou demasiado.', network: 'Sem ligação à internet ou serviço indisponível.', failed: 'A conversão falhou.', wrong: 'Algo correu mal: ',
      s: { upload: 'A carregar…', queued: 'Em fila…', read: 'A ler o ficheiro…', plain: 'A converter…', adobeSign: 'Adobe: a iniciar sessão…', adobeUpload: 'Adobe: a carregar…', adobeConvert: 'Adobe: a converter…', adobeDownload: 'Adobe: a transferir o resultado…', ccJob: 'CloudConvert: a criar tarefa…', ccUpload: 'CloudConvert: a carregar…', ccConvert: 'CloudConvert: a converter…', ccDownload: 'CloudConvert: a transferir o resultado…' }
    }
  };

  /* ---------- UI ---------- */
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function fmtSize(b) {
    if (b < 1024) return b + ' B';
    if (b < 1048576) return Math.round(b / 1024) + ' KB';
    return (b / 1048576).toFixed(1) + ' MB';
  }
  var KIND_LABEL = ['PDF → Word', 'Word → PDF', 'PPT → PDF', 'PDF → PPT'];

  function mount(el) {
    var lang = el.getAttribute('data-conv') || 'en', T = TEXT[lang] || TEXT.en;
    var maxMB = Math.round((CFG.maxFileBytes || 50 * 1048576) / 1048576);
    var st = { kind: KINDS[0], file: null, busy: false, ctl: null, result: null, error: '', status: '', drag: false };

    el.classList.add('cv');
    el.innerHTML =
      '<div class="cv-body"><div class="cv-label">' + esc(T.choose) + '</div>' +
      '<div class="cv-kinds" role="radiogroup" aria-label="' + esc(T.choose) + '">' +
      KINDS.map(function (k, i) {
        return '<button type="button" class="cv-kind" role="radio" data-kind="' + k.id + '"><span class="cv-badge">' + k.from + '<i>→</i>' + k.to + '</span><span class="cv-kt"><b>' + KIND_LABEL[i] + '</b><small>' + esc(T.kinds[i]) + '</small></span></button>';
      }).join('') + '</div>' +
      '<div class="cv-drop" data-el="drop" tabindex="0" role="button">' +
      '<svg class="cv-up" viewBox="0 0 24 24" width="38" height="38" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5M4 15v3.5A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5V15"/></svg>' +
      '<div class="cv-dt" data-el="dt"></div><div class="cv-ds" data-el="ds"></div>' +
      '<div class="cv-sup" data-el="sup"></div>' +
      '<input type="file" class="cv-file" data-el="file" hidden></div>' +
      '<div class="cv-prog" data-el="prog" hidden><span class="cv-spin" aria-hidden="true"></span><span data-el="status"></span><button type="button" class="cv-link" data-el="cancel">' + esc(T.cancel) + '</button><p>' + esc(T.large) + '</p></div>' +
      '<div class="cv-err" data-el="err" role="alert" hidden></div>' +
      '<div class="cv-res" data-el="res" hidden></div>' +
      '<div class="cv-actions"><button type="button" class="btn btn-p cv-go" data-el="go">' + esc(T.convert) + '</button></div>' +
      '<p class="cv-priv">' + esc(T.privacy) + '</p></div>';

    function q(n) { return el.querySelector('[data-el=' + n + ']'); }
    var drop = q('drop'), input = q('file');

    function render() {
      var kinds = el.querySelectorAll('.cv-kind');
      for (var i = 0; i < kinds.length; i++) {
        var on = kinds[i].getAttribute('data-kind') === st.kind.id;
        kinds[i].setAttribute('aria-checked', on ? 'true' : 'false');
        kinds[i].disabled = st.busy && !on;
      }
      input.accept = st.kind.inputs.map(function (e) { return '.' + e; }).join(',');
      drop.classList.toggle('is-drag', st.drag);
      drop.classList.toggle('is-has', !!st.file);
      drop.setAttribute('aria-disabled', st.busy ? 'true' : 'false');
      q('dt').textContent = st.drag ? T.dropActive : (st.file ? st.file.name : T.drop);
      var ds = q('ds');
      if (st.file && !st.drag) ds.textContent = fmtSize(st.file.size) + ' · ' + T.change;
      else { ds.textContent = T.or + ' '; var pk = document.createElement('span'); pk.className = 'cv-pick'; pk.textContent = T.pickBtn; ds.appendChild(pk); }
      q('sup').textContent = T.supports.replace('{x}', st.kind.inputs.map(function (e) { return e.toUpperCase(); }).join(', ')).replace('{n}', maxMB);
      q('prog').hidden = !st.busy;
      q('status').textContent = st.status;
      var err = q('err'); err.hidden = !st.error; err.textContent = st.error;
      var go = q('go'); go.disabled = !st.file || st.busy; go.textContent = T.convert;
      var res = q('res');
      if (st.result && !st.busy) {
        var r = st.result;
        res.hidden = false;
        res.innerHTML = '<div class="cv-ok"><b>✓ ' + esc(T.done) + '</b></div><div class="cv-rn"></div><div class="cv-rm"></div><div class="cv-ra"></div>';
        res.querySelector('.cv-rn').textContent = r.outName;
        res.querySelector('.cv-rm').textContent = (r.size ? fmtSize(r.size) + ' · ' : '') + T.via + ' ' + r.provider + (r.usedBackup ? ' (' + T.backup + ')' : '');
        var a = document.createElement('a');
        a.className = 'btn btn-s'; a.textContent = r.href && !r.blobUrl ? T.openLink : T.download;
        a.href = r.href; if (r.blobUrl) a.download = r.outName; else { a.target = '_blank'; a.rel = 'noopener'; }
        res.querySelector('.cv-ra').appendChild(a);
      } else { res.hidden = true; res.innerHTML = ''; }
    }

    function setFile(f) {
      if (st.busy || !f) return;
      var dot = f.name.lastIndexOf('.'), ext = dot >= 0 ? f.name.slice(dot + 1).toLowerCase() : '';
      if (st.kind.inputs.indexOf(ext) < 0) {
        st.error = T.wrongExt.replace('{x}', '.' + st.kind.inputs.join(' / .')).replace('{k}', st.kind.from + ' → ' + st.kind.to);
        render(); return;
      }
      st.file = f; st.error = ''; clearResult(); render();
    }
    function clearResult() {
      if (st.result && st.result.blobUrl) { try { URL.revokeObjectURL(st.result.href); } catch (e) {} }
      st.result = null;
    }

    el.addEventListener('click', function (e) {
      var kb = e.target.closest('.cv-kind');
      if (kb) {
        if (st.busy) return;
        var id = kb.getAttribute('data-kind'), k = KINDS.filter(function (x) { return x.id === id; })[0];
        if (k === st.kind) return;
        st.kind = k; st.error = ''; clearResult();
        if (st.file) { var d = st.file.name.lastIndexOf('.'), ex = st.file.name.slice(d + 1).toLowerCase(); if (k.inputs.indexOf(ex) < 0) st.file = null; }
        render(); return;
      }
      if (e.target.closest('[data-el=cancel]')) { if (st.ctl) st.ctl.cancel(); return; }
      if (e.target.closest('[data-el=go]')) { run(); return; }
      if (e.target.closest('[data-el=drop]') && !st.busy) input.click();
    });
    drop.addEventListener('keydown', function (e) { if ((e.key === 'Enter' || e.key === ' ') && !st.busy) { e.preventDefault(); input.click(); } });
    input.addEventListener('change', function () { var f = input.files && input.files[0]; input.value = ''; setFile(f); });
    ['dragenter', 'dragover'].forEach(function (n) { drop.addEventListener(n, function (e) { e.preventDefault(); if (!st.busy && !st.drag) { st.drag = true; render(); } }); });
    ['dragleave', 'dragend'].forEach(function (n) { drop.addEventListener(n, function () { if (st.drag) { st.drag = false; render(); } }); });
    drop.addEventListener('drop', function (e) { e.preventDefault(); st.drag = false; var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]; if (f) setFile(f); else render(); });
    window.addEventListener('beforeunload', function () { if (st.ctl) st.ctl.cancel(); });

    async function run() {
      var file = st.file;
      if (!file || st.busy) return;
      if (file.size > (CFG.maxFileBytes || 50 * 1048576)) { st.error = T.tooBig.replace('{n}', maxMB); render(); return; }
      var ctl = makeCancel();
      st.busy = true; st.ctl = ctl; st.error = ''; clearResult(); st.status = T.s.read; render();
      try {
        var res = await convertFile({
          kind: st.kind, file: file, cancel: ctl, T: T,
          onStatus: function (key) { st.status = T.s[key] || key; q('status').textContent = st.status; }
        });
        var dot = file.name.lastIndexOf('.');
        var outName = (dot > 0 ? file.name.slice(0, dot) : file.name) + '.' + st.kind.out;
        var result = { outName: outName, provider: res.provider, usedBackup: res.usedBackup };
        if (res.blob) {
          var blob = res.blob.type === MIME[st.kind.out] ? res.blob : new Blob([res.blob], { type: MIME[st.kind.out] });
          result.size = blob.size; result.href = URL.createObjectURL(blob); result.blobUrl = true;
        } else { result.href = res.url; result.blobUrl = false; }
        st.result = result; st.file = null;
        st.busy = false; st.ctl = null; render();
        if (result.blobUrl) { // auto-download, like the app saves straight to Downloads
          var a = document.createElement('a'); a.href = result.href; a.download = outName; document.body.appendChild(a); a.click(); a.remove();
        }
      } catch (e) {
        st.busy = false; st.ctl = null;
        if (e instanceof Cancelled) st.error = T.cancelled;
        else if (e instanceof ConversionError) st.error = e.message;
        else st.error = T.wrong + (e && e.message ? e.message : e);
        render();
      }
    }

    render();
  }

  function init() {
    var els = document.querySelectorAll('[data-conv]');
    for (var i = 0; i < els.length; i++) mount(els[i]);
  }

  var api = { KINDS: KINDS, MIME: MIME, convertFile: convertFile, makeCancel: makeCancel, ConversionError: ConversionError, Cancelled: Cancelled, errorText: errorText, _setConfig: function (c) { CFG = c; adobeTok = { token: null, expiry: 0 }; } };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof document !== 'undefined') {
    root.AgentoConverter = api;
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  }
})(typeof window !== 'undefined' ? window : globalThis);
