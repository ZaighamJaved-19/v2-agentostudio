import json
import time

import httpx
import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app

PDF = b"%PDF-1.4 fake pdf"
DOCX = b"PK\x03\x04 fake docx"


def settings(**kw):
    base = dict(
        adobe_client_id="ADOBE_ID", adobe_client_secret="ADOBE_SECRET", cloudconvert_api_key="CC_KEY",
        cloudconvert_poll_seconds=0.01, adobe_min_retry_seconds=0.01, rate_limit_per_hour=100,
        allowed_origins=("https://agentostudio.tech",),
    )
    base.update(kw)
    return Settings(**base)


class Mock:
    """Fake Adobe + CloudConvert."""

    def __init__(self, adobe="ok", cc="ok", adobe_delay=False):
        self.adobe, self.cc, self.calls, self.payloads, self.adobe_delay = adobe, cc, [], [], adobe_delay

    def __call__(self, req: httpx.Request) -> httpx.Response:
        url = str(req.url)
        self.calls.append(f"{req.method} {url}")
        if "pdf-services.adobe.io/token" in url:
            if self.adobe == "signin_fail":
                return httpx.Response(401, json={"error": {"message": "bad creds"}})
            assert b"client_id=ADOBE_ID" in req.content and b"client_secret=ADOBE_SECRET" in req.content
            return httpx.Response(200, json={"access_token": "tok", "expires_in": 86399999})
        if "pdf-services.adobe.io/assets" in url:
            assert req.headers["x-api-key"] == "ADOBE_ID" and req.headers["authorization"] == "Bearer tok"
            return httpx.Response(200, json={"assetID": "a1", "uploadUri": "https://up.adobe/put"})
        if url == "https://up.adobe/put":
            return httpx.Response(200)
        if "/operation/" in url:
            self.payloads.append((url.rsplit("/", 1)[1], json.loads(req.content)))
            return httpx.Response(201, headers={"location": "https://pdf-services.adobe.io/job/1"})
        if url.endswith("/job/1"):
            if self.adobe == "job_failed":
                return httpx.Response(200, json={"status": "failed", "error": {"message": "corrupt"}})
            return httpx.Response(200, json={"status": "done", "asset": {"downloadUri": "https://dl.adobe/f"}})
        if url == "https://dl.adobe/f":
            return httpx.Response(200, content=b"ADOBE-RESULT")
        if "cloudconvert.com/v2/jobs" in url and req.method == "POST":
            if self.cc == "reject":
                return httpx.Response(402, json={"message": "quota exceeded"})
            body = json.loads(req.content)
            self.payloads.append(("cc", body["tasks"]["convert-file"]["output_format"]))
            return httpx.Response(201, json={"data": {"id": "j1", "tasks": [{"name": "import-file", "result": {"form": {"url": "https://cc.up/form", "parameters": {"key": "k"}}}}]}})
        if url == "https://cc.up/form":
            raw = req.content
            assert raw.index(b'name="key"') < raw.index(b'name="file"'), "file must be the LAST form field"
            return httpx.Response(201)
        if url.endswith("/jobs/j1"):
            return httpx.Response(200, json={"data": {"status": "finished", "tasks": [{"name": "export-file", "result": {"files": [{"url": "https://cc.dl/out"}]}}]}})
        if url == "https://cc.dl/out":
            return httpx.Response(200, content=b"CC-RESULT")
        raise AssertionError("unexpected request " + url)


def make(mock=None, **kw):
    mock = mock or Mock()
    client = httpx.AsyncClient(transport=httpx.MockTransport(mock))
    return TestClient(create_app(settings(**kw), client)), mock


def wait(c, job_id, timeout=10):
    end = time.time() + timeout
    while time.time() < end:
        j = c.get(f"/api/jobs/{job_id}").json()
        if j["status"] in ("done", "error", "cancelled"):
            return j
        time.sleep(0.02)
    raise AssertionError("job did not finish")


def submit(c, name="notes.pdf", data=PDF, kind="pdfToWord"):
    return c.post("/api/convert", files={"file": (name, data)}, data={"kind": kind})


def test_adobe_primary_pdf_to_word():
    cl, mock = make()
    with cl as c:
        r = submit(c)
        assert r.status_code == 202
        j = wait(c, r.json()["jobId"])
        assert j["status"] == "done" and j["provider"] == "Adobe PDF Services" and j["usedBackup"] is False
        assert j["outName"] == "notes.docx"
        f = c.get(f"/api/jobs/{j['id']}/file")
        assert f.status_code == 200 and f.content == b"ADOBE-RESULT"
        assert "wordprocessingml" in f.headers["content-type"] and "notes.docx" in f.headers["content-disposition"]
    assert ("exportpdf", {"assetID": "a1", "targetFormat": "docx"}) in mock.payloads


def test_word_to_pdf_uses_createpdf_without_target_format():
    cl, mock = make()
    with cl as c:
        j = wait(c, submit(c, "a.docx", DOCX, "wordToPdf").json()["jobId"])
        assert j["status"] == "done" and j["outName"] == "a.pdf"
    assert mock.payloads == [("createpdf", {"assetID": "a1"})]


def test_ppt_to_pdf_and_pdf_to_ppt():
    cl, mock = make()
    with cl as c:
        assert wait(c, submit(c, "s.pptx", DOCX, "pptToPdf").json()["jobId"])["outName"] == "s.pdf"
        assert wait(c, submit(c, "s.pdf", PDF, "pdfToPpt").json()["jobId"])["outName"] == "s.pptx"
    assert ("exportpdf", {"assetID": "a1", "targetFormat": "pptx"}) in mock.payloads


@pytest.mark.parametrize("adobe", ["signin_fail", "job_failed"])
def test_adobe_failure_falls_back_to_cloudconvert(adobe):
    cl, mock = make(Mock(adobe=adobe))
    with cl as c:
        j = wait(c, submit(c).json()["jobId"])
        assert j["status"] == "done" and j["provider"] == "CloudConvert" and j["usedBackup"] is True
        assert c.get(f"/api/jobs/{j['id']}/file").content == b"CC-RESULT"
    assert ("cc", "docx") in mock.payloads


def test_cloudconvert_only_when_adobe_not_configured():
    cl, mock = make(adobe_client_id="", adobe_client_secret="")
    with cl as c:
        j = wait(c, submit(c).json()["jobId"])
        assert j["provider"] == "CloudConvert" and j["usedBackup"] is False
    assert not any("adobe" in x for x in mock.calls)


def test_adobe_only_error_message_is_shown():
    cl, _ = make(Mock(adobe="signin_fail"), cloudconvert_api_key="")
    with cl as c:
        j = wait(c, submit(c).json()["jobId"])
        assert j["status"] == "error" and "bad creds" in j["error"]


def test_both_fail_shows_cloudconvert_error():
    cl, _ = make(Mock(adobe="signin_fail", cc="reject"))
    with cl as c:
        j = wait(c, submit(c).json()["jobId"])
        assert j["status"] == "error" and "CloudConvert rejected the job (402): quota exceeded" in j["error"]
        assert c.get(f"/api/jobs/{j['id']}/file").status_code == 409


def test_validation_errors():
    cl, _ = make()
    with cl as c:
        assert submit(c, "a.docx", DOCX, "pdfToWord").status_code == 400          # wrong extension for kind
        assert submit(c, "a.pdf", b"not a pdf at all", "pdfToWord").status_code == 400  # bad magic bytes
        assert submit(c, "a.pdf", b"", "pdfToWord").status_code == 400
        assert submit(c, "a.pdf", PDF, "nope").status_code == 400                  # unknown kind
        assert c.get("/api/jobs/doesnotexist").status_code == 404


def test_too_large_and_rate_limit():
    cl, _ = make(max_file_bytes=100)
    with cl as c:
        assert submit(c, "big.pdf", PDF + b"x" * 200).status_code == 413
    cl, _ = make(rate_limit_per_hour=2)
    with cl as c:
        assert submit(c).status_code == 202 and submit(c).status_code == 202
        r = submit(c)
        assert r.status_code == 429 and "Too many" in r.json()["detail"]


def test_not_configured_returns_503():
    cl, _ = make(adobe_client_id="", adobe_client_secret="", cloudconvert_api_key="")
    with cl as c:
        assert submit(c).status_code == 503


def test_cancel_removes_job():
    cl, _ = make()
    with cl as c:
        jid = submit(c).json()["jobId"]
        assert c.delete(f"/api/jobs/{jid}").status_code == 204
        assert c.get(f"/api/jobs/{jid}").status_code == 404


def test_health_never_exposes_keys():
    cl, _ = make()
    with cl as c:
        r = c.get("/health")
        assert r.json() == {"ok": True, "adobe": True, "cloudconvert": True}
        assert "SECRET" not in r.text and "CC_KEY" not in r.text


def test_cors_only_for_allowed_origin():
    cl, _ = make()
    with cl as c:
        ok = c.get("/health", headers={"Origin": "https://agentostudio.tech"})
        assert ok.headers.get("access-control-allow-origin") == "https://agentostudio.tech"
        bad = c.get("/health", headers={"Origin": "https://evil.example"})
        assert "access-control-allow-origin" not in bad.headers
        pre = c.options("/api/convert", headers={"Origin": "https://agentostudio.tech", "Access-Control-Request-Method": "POST"})
        assert pre.status_code == 200


def test_unsafe_filename_is_sanitised():
    cl, _ = make()
    with cl as c:
        j = wait(c, submit(c, "../../etc/pa:ss?wd.pdf").json()["jobId"])
        assert j["outName"] == "pa_ss_wd.docx"
