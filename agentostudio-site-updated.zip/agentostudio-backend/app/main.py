"""Agento Studio — document converter API (FastAPI).

Endpoints
  GET    /health                 which providers are configured (booleans only, never keys)
  POST   /api/convert            multipart: file + kind  ->  {"jobId": "..."}
  GET    /api/jobs/{id}          status / stage / provider / error
  GET    /api/jobs/{id}/file     the converted file (once status == "done")
  DELETE /api/jobs/{id}          cancel and delete

Files live in a private temp directory only until JOB_TTL_SECONDS has passed.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import secrets
import shutil
import tempfile
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from pathlib import Path

import httpx
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response

from .config import Settings
from .providers import KINDS, MIME, ConversionError, ConversionService, friendly

log = logging.getLogger("agento.converter")

# Magic bytes: reject files that are not really what their extension says.
_OLE = b"\xd0\xcf\x11\xe0"


def _looks_valid(ext: str, head: bytes) -> bool:
    if ext == "pdf":
        return b"%PDF" in head[:1024]
    if ext in ("docx", "pptx"):
        return head[:2] == b"PK"
    if ext in ("doc", "ppt"):
        return head[:4] == _OLE
    return False


@dataclass
class Job:
    id: str
    filename: str
    out_name: str
    kind_id: str
    ip: str
    created: float = field(default_factory=time.time)
    finished: float | None = None
    status: str = "queued"  # queued | running | done | error | cancelled
    stage: str = "queued"
    error: str | None = None
    provider: str | None = None
    used_backup: bool = False
    size: int = 0
    path: Path | None = None
    task: asyncio.Task | None = None

    def public(self) -> dict:
        return {
            "id": self.id,
            "status": self.status,
            "stage": self.stage,
            "error": self.error,
            "provider": self.provider,
            "usedBackup": self.used_backup,
            "outName": self.out_name,
            "size": self.size,
        }


class RateLimiter:
    """Sliding one-hour window per client IP (in memory — fine for a single instance)."""

    def __init__(self, per_hour: int):
        self.per_hour = per_hour
        self.hits: dict[str, deque[float]] = defaultdict(deque)

    def allow(self, key: str) -> bool:
        if self.per_hour <= 0:
            return True
        now = time.time()
        q = self.hits[key]
        while q and now - q[0] > 3600:
            q.popleft()
        if len(q) >= self.per_hour:
            return False
        q.append(now)
        return True


def _safe_out_name(filename: str, out_ext: str) -> str:
    base = os.path.basename(filename.replace("\\", "/"))
    base = base.rsplit(".", 1)[0] if "." in base else base
    base = re.sub(r"[\x00-\x1f\x7f<>:\"/\\|?*]", "_", base).strip(" .") or "converted"
    return f"{base[:120]}.{out_ext}"


def create_app(settings: Settings | None = None, http_client: httpx.AsyncClient | None = None) -> FastAPI:
    settings = settings or Settings.from_env()
    jobs: dict[str, Job] = {}
    limiter = RateLimiter(settings.rate_limit_per_hour)
    state: dict = {}

    def drop(job: Job) -> None:
        if job.path:
            shutil.rmtree(job.path.parent, ignore_errors=True)
            job.path = None

    async def janitor() -> None:
        while True:
            await asyncio.sleep(30)
            now = time.time()
            for jid, job in list(jobs.items()):
                ref = job.finished or job.created
                if job.status in ("done", "error", "cancelled") and now - ref > settings.job_ttl_seconds:
                    drop(job)
                    jobs.pop(jid, None)
                elif now - job.created > settings.job_ttl_seconds + 900:  # safety net for stuck jobs
                    if job.task and not job.task.done():
                        job.task.cancel()
                    drop(job)
                    jobs.pop(jid, None)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        own_client = http_client is None
        client = http_client or httpx.AsyncClient(follow_redirects=True)
        state["service"] = ConversionService(client, settings)
        state["sem"] = asyncio.Semaphore(settings.max_concurrent)
        state["tmp"] = Path(tempfile.mkdtemp(prefix="agento-conv-"))
        cleaner = asyncio.create_task(janitor())
        try:
            yield
        finally:
            cleaner.cancel()
            for j in jobs.values():
                if j.task and not j.task.done():
                    j.task.cancel()
            shutil.rmtree(state["tmp"], ignore_errors=True)
            if own_client:
                await client.aclose()

    app = FastAPI(title="Agento Studio converter", version="1.0", lifespan=lifespan, docs_url=None, redoc_url=None)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.allowed_origins),
        allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
        allow_headers=["*"],
        expose_headers=["Content-Disposition"],
        max_age=600,
    )

    def client_ip(request: Request) -> str:
        if settings.trust_proxy:
            fwd = request.headers.get("x-forwarded-for")
            if fwd:
                return fwd.split(",")[0].strip()
        return request.client.host if request.client else "unknown"

    async def run_job(job: Job, data: bytes, kind_id: str) -> None:
        kind = KINDS[kind_id]
        try:
            async with state["sem"]:
                job.status, job.stage = "running", "plain"

                def on_status(stage: str) -> None:
                    job.stage = stage

                res = await state["service"].convert(kind, data, job.filename, on_status)
            folder = state["tmp"] / job.id
            folder.mkdir(parents=True, exist_ok=True)
            out = folder / "result"
            out.write_bytes(res.data)
            job.path, job.size = out, len(res.data)
            job.provider, job.used_backup = res.provider, res.used_backup
            job.status, job.stage = "done", "done"
        except asyncio.CancelledError:
            job.status, job.stage, job.error = "cancelled", "cancelled", "Conversion cancelled."
            raise
        except ConversionError as e:
            job.status, job.error = "error", str(e)
        except Exception as e:  # noqa: BLE001
            log.exception("Unexpected conversion failure")
            job.status, job.error = "error", "Something went wrong: " + friendly(e)
        finally:
            job.finished = time.time()

    @app.get("/health")
    async def health() -> dict:
        return {"ok": True, "adobe": settings.adobe_ready, "cloudconvert": settings.cloudconvert_ready}

    @app.post("/api/convert", status_code=202)
    async def convert(request: Request, file: UploadFile = File(...), kind: str = Form(...)) -> dict:
        if kind not in KINDS:
            raise HTTPException(400, "Unknown conversion type.")
        k = KINDS[kind]
        if not settings.any_provider:
            raise HTTPException(503, "No converter is set up yet.")
        declared = request.headers.get("content-length")
        if declared and declared.isdigit() and int(declared) > settings.max_file_bytes + 1024 * 1024:
            raise HTTPException(413, f"This file is larger than {settings.max_file_bytes // (1024 * 1024)} MB.")
        name = file.filename or "file"
        dot = name.rfind(".")
        ext = name[dot + 1 :].lower() if dot >= 0 else ""
        if ext not in k.inputs:
            raise HTTPException(400, f"Please choose a .{' / .'.join(k.inputs)} file for {k.label}.")
        data = await file.read(settings.max_file_bytes + 1)
        if len(data) > settings.max_file_bytes:
            raise HTTPException(413, f"This file is larger than {settings.max_file_bytes // (1024 * 1024)} MB.")
        if not data or not _looks_valid(ext, data[:1024]):
            raise HTTPException(400, f"This does not look like a valid .{ext} file.")
        ip = client_ip(request)
        if not limiter.allow(ip):
            raise HTTPException(429, "Too many conversions from your network. Please try again later.")

        job = Job(id=secrets.token_urlsafe(16), filename=name, out_name=_safe_out_name(name, k.out), kind_id=kind, ip=ip)
        jobs[job.id] = job
        job.task = asyncio.create_task(run_job(job, data, kind))
        return {"jobId": job.id}

    def get_job(job_id: str) -> Job:
        job = jobs.get(job_id)
        if not job:
            raise HTTPException(404, "Job not found or expired.")
        return job

    @app.get("/api/jobs/{job_id}")
    async def job_status(job_id: str) -> dict:
        return get_job(job_id).public()

    @app.get("/api/jobs/{job_id}/file")
    async def job_file(job_id: str):
        job = get_job(job_id)
        if job.status != "done" or not job.path or not job.path.exists():
            raise HTTPException(409, "The file is not ready.")
        out_ext = KINDS[job.kind_id].out
        return FileResponse(job.path, media_type=MIME[out_ext], filename=job.out_name, headers={"Cache-Control": "no-store"})

    @app.delete("/api/jobs/{job_id}", status_code=204)
    async def job_cancel(job_id: str) -> Response:
        job = get_job(job_id)
        if job.task and not job.task.done():
            job.task.cancel()
        drop(job)
        jobs.pop(job_id, None)
        return Response(status_code=204)

    @app.exception_handler(HTTPException)
    async def http_exc(_: Request, exc: HTTPException):
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code, headers=getattr(exc, "headers", None))

    return app


# `uvicorn app.main:app` — the app is created lazily so importing this module never fails without keys.
def _lazy_app() -> FastAPI:
    return create_app()


app = _lazy_app()
