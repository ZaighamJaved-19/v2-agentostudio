"""Settings, read from environment variables (and an optional local .env file)."""
from __future__ import annotations

import os
from dataclasses import dataclass

try:  # optional: load a local .env during development
    from dotenv import load_dotenv

    load_dotenv()
except Exception:  # pragma: no cover
    pass


def _bool(value: str | None, default: bool = False) -> bool:
    if value is None or value == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _int(value: str | None, default: int) -> int:
    try:
        return int(value) if value not in (None, "") else default
    except ValueError:
        return default


DEFAULT_ORIGINS = (
    "https://agentostudio.tech,https://www.agentostudio.tech,"
    "http://localhost:8765,http://127.0.0.1:8765,http://localhost:8000,http://127.0.0.1:8000"
)


@dataclass(frozen=True)
class Settings:
    adobe_client_id: str = ""
    adobe_client_secret: str = ""
    cloudconvert_api_key: str = ""
    cloudconvert_sandbox: bool = False
    max_file_bytes: int = 50 * 1024 * 1024
    allowed_origins: tuple[str, ...] = tuple(DEFAULT_ORIGINS.split(","))
    rate_limit_per_hour: int = 20
    max_concurrent: int = 3
    job_ttl_seconds: int = 900
    trust_proxy: bool = False
    # polling cadence (overridable so tests run fast)
    cloudconvert_poll_seconds: float = 2.0
    adobe_min_retry_seconds: float = 1.0

    @property
    def adobe_ready(self) -> bool:
        return bool(self.adobe_client_id and self.adobe_client_secret)

    @property
    def cloudconvert_ready(self) -> bool:
        return bool(self.cloudconvert_api_key)

    @property
    def any_provider(self) -> bool:
        return self.adobe_ready or self.cloudconvert_ready

    @classmethod
    def from_env(cls) -> "Settings":
        e = os.environ.get
        origins = [o.strip().rstrip("/") for o in (e("ALLOWED_ORIGINS") or DEFAULT_ORIGINS).split(",") if o.strip()]
        return cls(
            adobe_client_id=(e("ADOBE_CLIENT_ID") or "").strip(),
            adobe_client_secret=(e("ADOBE_CLIENT_SECRET") or "").strip(),
            cloudconvert_api_key=(e("CLOUDCONVERT_API_KEY") or "").strip(),
            cloudconvert_sandbox=_bool(e("CLOUDCONVERT_SANDBOX")),
            max_file_bytes=_int(e("MAX_FILE_MB"), 50) * 1024 * 1024,
            allowed_origins=tuple(origins),
            rate_limit_per_hour=_int(e("RATE_LIMIT_PER_HOUR"), 20),
            max_concurrent=max(1, _int(e("MAX_CONCURRENT"), 3)),
            job_ttl_seconds=_int(e("JOB_TTL_SECONDS"), 900),
            trust_proxy=_bool(e("TRUST_PROXY")),
        )
