"""Conversion providers — a faithful port of doc_converter_feature.dart.

Adobe PDF Services (PRIMARY):
    POST /token -> POST /assets -> PUT uploadUri -> POST /operation/{exportpdf|createpdf}
    -> poll the Location header until status == "done" -> GET downloadUri
CloudConvert (BACKUP, automatic when Adobe fails or is not configured):
    POST /jobs (import/upload + convert + export/url) -> upload to the returned form
    -> poll the job -> download the exported file
"""
from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass
from typing import Awaitable, Callable

import httpx

from .config import Settings

OnStatus = Callable[[str], None]

MIME = {
    "pdf": "application/pdf",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "doc": "application/msword",
    "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "ppt": "application/vnd.ms-powerpoint",
}


@dataclass(frozen=True)
class Kind:
    id: str
    label: str
    inputs: tuple[str, ...]
    out: str
    is_export: bool  # PDF -> Office uses Adobe "exportpdf"; Office -> PDF uses "createpdf"


KINDS: dict[str, Kind] = {
    k.id: k
    for k in (
        Kind("pdfToWord", "PDF → Word", ("pdf",), "docx", True),
        Kind("wordToPdf", "Word → PDF", ("docx", "doc"), "pdf", False),
        Kind("pptToPdf", "PPT → PDF", ("pptx", "ppt"), "pdf", False),
        Kind("pdfToPpt", "PDF → PPT", ("pdf",), "pptx", True),
    )
}


class ConversionError(Exception):
    """A user-presentable conversion failure."""


def error_text(body: str) -> str:
    try:
        j = json.loads(body)
        if isinstance(j, dict):
            e = j.get("error")
            if isinstance(e, dict) and e.get("message") is not None:
                return str(e["message"])
            if isinstance(e, str):
                return e
            if j.get("message") is not None:
                return str(j["message"])
            if j.get("error_description") is not None:
                return str(j["error_description"])
    except Exception:
        pass
    return body if len(body) <= 200 else body[:200] + "…"


def friendly(e: Exception) -> str:
    if isinstance(e, ConversionError):
        return str(e)
    if isinstance(e, httpx.TimeoutException):
        return "The request timed out."
    if isinstance(e, httpx.HTTPError):
        return "The conversion service could not be reached."
    return str(e) or e.__class__.__name__


# --------------------------------------------------------------------------- Adobe
class AdobeProvider:
    BASE = "https://pdf-services.adobe.io"

    def __init__(self, client: httpx.AsyncClient, settings: Settings):
        self._c = client
        self._s = settings
        self._token: str | None = None
        self._expiry = 0.0
        self._lock = asyncio.Lock()

    async def _access_token(self) -> str:
        async with self._lock:
            if self._token and time.time() < self._expiry:
                return self._token
            r = await self._c.post(
                f"{self.BASE}/token",
                data={"client_id": self._s.adobe_client_id, "client_secret": self._s.adobe_client_secret},
                timeout=30,
            )
            if r.status_code != 200:
                raise ConversionError(f"Adobe sign-in failed ({r.status_code}): {error_text(r.text)}")
            j = r.json()
            self._token = j["access_token"]
            secs = int(j.get("expires_in") or 3600)
            life = secs // 1000 if secs > 100000 else secs  # seconds or milliseconds
            self._expiry = time.time() + life - 60
            return self._token

    def _auth(self, token: str, json_body: bool = False) -> dict[str, str]:
        h = {"Authorization": f"Bearer {token}", "x-api-key": self._s.adobe_client_id}
        if json_body:
            h["Content-Type"] = "application/json"
        return h

    async def convert(self, kind: Kind, data: bytes, ext: str, on_status: OnStatus) -> bytes:
        mime = MIME[ext]
        on_status("adobeSign")
        token = await self._access_token()

        # 1) ask for an upload slot
        on_status("adobeUpload")
        slot = await self._c.post(
            f"{self.BASE}/assets", headers=self._auth(token, True), content=json.dumps({"mediaType": mime}), timeout=30
        )
        if slot.status_code not in (200, 202):
            raise ConversionError(f"Adobe upload slot failed ({slot.status_code}): {error_text(slot.text)}")
        sj = slot.json()
        asset_id, upload_uri = sj["assetID"], sj["uploadUri"]

        # 2) upload to the pre-signed URL
        up = await self._c.put(upload_uri, headers={"Content-Type": mime}, content=data, timeout=300)
        if up.status_code not in (200, 201):
            raise ConversionError(f"Adobe upload failed ({up.status_code}).")

        # 3) submit the job
        on_status("adobeConvert")
        op = "exportpdf" if kind.is_export else "createpdf"
        payload: dict = {"assetID": asset_id}
        if kind.is_export:
            payload["targetFormat"] = kind.out  # docx | pptx
        submit = await self._c.post(
            f"{self.BASE}/operation/{op}", headers=self._auth(token, True), content=json.dumps(payload), timeout=30
        )
        if submit.status_code != 201:
            raise ConversionError(f"Adobe rejected the job ({submit.status_code}): {error_text(submit.text)}")
        location = submit.headers.get("location")
        if not location:
            raise ConversionError("Adobe did not return a job location.")

        # 4) poll until done
        deadline = time.time() + 6 * 60
        download_uri: str | None = None
        while True:
            if time.time() > deadline:
                raise ConversionError("Adobe took too long to finish.")
            p = await self._c.get(location, headers=self._auth(token), timeout=30)
            if p.status_code not in (200, 202):
                raise ConversionError(f"Adobe status check failed ({p.status_code}): {error_text(p.text)}")
            j = p.json()
            status = str(j.get("status") or "").lower()
            if status == "done":
                download_uri = (j.get("asset") or {}).get("downloadUri")
                break
            if status == "failed":
                raise ConversionError(f"Adobe could not convert this file: {error_text(p.text)}")
            try:
                retry = int(p.headers.get("retry-after", ""))
            except ValueError:
                retry = 2
            await asyncio.sleep(max(self._s.adobe_min_retry_seconds, min(5, retry)))
        if not download_uri:
            raise ConversionError("Adobe finished but returned no file.")

        # 5) download (pre-signed URL: no auth headers)
        on_status("adobeDownload")
        dl = await self._c.get(download_uri, timeout=300)
        if dl.status_code != 200:
            raise ConversionError(f"Adobe download failed ({dl.status_code}).")
        return dl.content


# ----------------------------------------------------------------------- CloudConvert
class CloudConvertProvider:
    def __init__(self, client: httpx.AsyncClient, settings: Settings):
        self._c = client
        self._s = settings

    @property
    def _base(self) -> str:
        return "https://api.sandbox.cloudconvert.com/v2" if self._s.cloudconvert_sandbox else "https://api.cloudconvert.com/v2"

    @property
    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._s.cloudconvert_api_key}", "Content-Type": "application/json"}

    async def convert(self, kind: Kind, data: bytes, filename: str, on_status: OnStatus) -> bytes:
        on_status("ccJob")
        create = await self._c.post(
            f"{self._base}/jobs",
            headers=self._headers,
            content=json.dumps(
                {
                    "tasks": {
                        "import-file": {"operation": "import/upload"},
                        "convert-file": {"operation": "convert", "input": "import-file", "output_format": kind.out},
                        "export-file": {"operation": "export/url", "input": "convert-file"},
                    }
                }
            ),
            timeout=30,
        )
        if create.status_code != 201:
            raise ConversionError(f"CloudConvert rejected the job ({create.status_code}): {error_text(create.text)}")
        d = create.json()["data"]
        job_id = d["id"]
        import_task = next(t for t in d["tasks"] if t["name"] == "import-file")
        form = import_task["result"]["form"]

        # upload: every form parameter first, the file LAST (field name "file")
        on_status("ccUpload")
        up = await self._c.post(
            form["url"],
            data={k: str(v) for k, v in form["parameters"].items()},
            files={"file": (filename, data)},
            timeout=300,
        )
        if up.status_code >= 400:
            raise ConversionError(f"CloudConvert upload failed ({up.status_code}).")

        # poll
        on_status("ccConvert")
        deadline = time.time() + 6 * 60
        url: str | None = None
        while True:
            if time.time() > deadline:
                raise ConversionError("CloudConvert took too long to finish.")
            await asyncio.sleep(self._s.cloudconvert_poll_seconds)
            r = await self._c.get(f"{self._base}/jobs/{job_id}", headers=self._headers, timeout=30)
            if r.status_code != 200:
                raise ConversionError(f"CloudConvert status check failed ({r.status_code}): {error_text(r.text)}")
            job = r.json()["data"]
            tasks = job.get("tasks") or []
            if job.get("status") == "error":
                bad = [t for t in tasks if t.get("status") == "error"]
                msg = (bad[0].get("message") or bad[0].get("code") or "unknown error") if bad else "unknown error"
                raise ConversionError(f"CloudConvert could not convert this file: {msg}")
            if job.get("status") == "finished":
                export = next(t for t in tasks if t["name"] == "export-file")
                files = (export.get("result") or {}).get("files") or []
                if not files:
                    raise ConversionError("CloudConvert returned no file.")
                url = files[0]["url"]
                break

        on_status("ccDownload")
        dl = await self._c.get(url, timeout=300)
        if dl.status_code != 200:
            raise ConversionError(f"CloudConvert download failed ({dl.status_code}).")
        return dl.content


# ----------------------------------------------------------------------------- service
@dataclass(frozen=True)
class ConversionResult:
    data: bytes
    provider: str
    used_backup: bool


class ConversionService:
    """Adobe first, CloudConvert as automatic backup (same rules as DocConversionService in Dart)."""

    def __init__(self, client: httpx.AsyncClient, settings: Settings):
        self._s = settings
        self._adobe = AdobeProvider(client, settings)
        self._cloud = CloudConvertProvider(client, settings)

    async def convert(self, kind: Kind, data: bytes, filename: str, on_status: OnStatus) -> ConversionResult:
        if not self._s.any_provider:
            raise ConversionError("No converter is set up yet. Add the API keys to the backend environment.")
        dot = filename.rfind(".")
        ext = filename[dot + 1 :].lower() if dot >= 0 else ""
        if ext not in kind.inputs:
            raise ConversionError(f"Please choose a .{' / .'.join(kind.inputs)} file for {kind.label}.")

        adobe_error: str | None = None
        cloud_error: str | None = None
        if self._s.adobe_ready:
            try:
                out = await self._adobe.convert(kind, data, ext, on_status)
                return ConversionResult(out, "Adobe PDF Services", False)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001 - any Adobe failure triggers the backup
                adobe_error = friendly(e)
                if self._s.cloudconvert_ready:
                    on_status("plain")
        if self._s.cloudconvert_ready:
            try:
                out = await self._cloud.convert(kind, data, filename, on_status)
                return ConversionResult(out, "CloudConvert", self._s.adobe_ready)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001
                cloud_error = friendly(e)
        # Show CloudConvert's error if it ran; Adobe's only when Adobe was the only provider.
        raise ConversionError(cloud_error or adobe_error or "Conversion failed.")
