# Agento Studio — converter backend

Small FastAPI service that does the four document conversions for the website
(PDF→Word, Word→PDF, PPT→PDF, PDF→PPT). It is a port of `doc_converter_feature.dart`:

1. **Adobe PDF Services** is tried first.
2. If Adobe fails (or is not configured) it **automatically falls back to CloudConvert**.

The API keys live only in this service's environment variables — they never reach the browser.

> Keep this folder **out of** the static site you deploy (`agentostudio-site-main-new/`).

## 1. Run it on your PC

```bat
cd agentostudio-backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

Open `.env` and paste your keys:

```
ADOBE_CLIENT_ID=...          (client_id from pdfservices-api-credentials.json)
ADOBE_CLIENT_SECRET=...      (client_secret from the same file)
CLOUDCONVERT_API_KEY=...     (scopes task.read + task.write)
```

Start it:

```bat
uvicorn app.main:app --port 8000
```

Check http://localhost:8000/health — it should show `"adobe": true, "cloudconvert": true`.

In another terminal serve the website (`python -m http.server 8765` inside `agentostudio-site-main-new`)
and open http://localhost:8765/pdf-word-converter/ — the site automatically talks to
`http://localhost:8000` when it is opened from localhost.

## 2. Deploy it

Any host that runs a Dockerfile or Python works. The service listens on `$PORT` (default 8000).

**Render / Railway / Fly.io (Docker):** create a new Web Service from this folder, let it use the `Dockerfile`,
and add the environment variables from `.env.example` in the host's dashboard
(`ADOBE_CLIENT_ID`, `ADOBE_CLIENT_SECRET`, `CLOUDCONVERT_API_KEY`, `ALLOWED_ORIGINS`, `TRUST_PROXY=true`).

**Without Docker:** build command `pip install -r requirements.txt`,
start command `uvicorn app.main:app --host 0.0.0.0 --port $PORT --proxy-headers`.

Then open `agentostudio-site-main-new/assets/js/converter-config.js` and set your public URL:

```js
apiBase: "https://converter.agentostudio.tech"   // or https://your-app.onrender.com
```

Redeploy the website. Make sure `ALLOWED_ORIGINS` contains your site (`https://agentostudio.tech`).

## API

| Method | Path | Purpose |
| ------ | ---- | ------- |
| `GET` | `/health` | which providers are configured (booleans only) |
| `POST` | `/api/convert` | multipart `file` + `kind` (`pdfToWord`, `wordToPdf`, `pptToPdf`, `pdfToPpt`) → `{"jobId"}` |
| `GET` | `/api/jobs/{id}` | `status` (`queued`/`running`/`done`/`error`/`cancelled`), `stage`, `provider`, `usedBackup`, `error` |
| `GET` | `/api/jobs/{id}/file` | the converted file |
| `DELETE` | `/api/jobs/{id}` | cancel + delete |

Converted files are deleted after `JOB_TTL_SECONDS` (default 15 minutes). Uploaded files are only held in
memory while converting.

## Protection built in

- Keys only in environment variables; `/health` never returns them.
- CORS limited to `ALLOWED_ORIGINS`.
- Per-IP limit (`RATE_LIMIT_PER_HOUR`, default 20), max file size (`MAX_FILE_MB`, default 50),
  concurrent-job cap (`MAX_CONCURRENT`), and a file-signature check (a `.pdf` must really be a PDF).
- Job IDs are random and unguessable.

Note: the rate limiter and job list are in memory, so run **one instance** (the default on free tiers).
Many free tiers sleep when idle — the first conversion after a pause can be slow.

## Tests

```bat
pip install -r requirements-dev.txt
python -m pytest -q
```
